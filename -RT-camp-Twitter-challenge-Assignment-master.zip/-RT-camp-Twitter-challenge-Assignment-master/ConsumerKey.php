<?php
define('CONSUMER_KEY', 'GWWzfjy8vMI2IUQPrHzjtCX9n'); // add your app consumer key between single quotes
define('CONSUMER_SECRET', '8Y5uv0QcrZ4bB1n41GSXM40UOhNpu0f3YzP4EwSUmn2E2Bnien'); // add your app consumer secret key between single quotes
define('OAUTH_CALLBACK', 'https://jatin-kaklotar.000webhostapp.com/twitter_demo/callback.php'); // your app callback URL